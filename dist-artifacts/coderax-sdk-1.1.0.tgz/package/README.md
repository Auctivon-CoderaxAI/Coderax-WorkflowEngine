# @coderax/sdk

Version 1.1.0. Requires engine contract 1.1.0 and event schema 1.

Install both tarballs from the same release:

```sh
npm install ./coderax-contracts-1.1.0.tgz ./coderax-sdk-1.1.0.tgz
```

Then call `client.negotiate()` before issuing requests. It throws
`CoderaxCompatibilityError` when the engine cannot satisfy this SDK.
