# @coderax/contracts

Version 1.1.0. Event schema 1.
Generated from Coderax WorkflowEngine. Do not edit inside the tarball.
